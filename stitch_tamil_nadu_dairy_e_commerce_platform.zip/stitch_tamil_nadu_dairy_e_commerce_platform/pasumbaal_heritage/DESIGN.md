---
name: Pasumbaal Heritage
colors:
  surface: '#fff8f6'
  surface-dim: '#e6d7d1'
  surface-bright: '#fff8f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1eb'
  surface-container: '#faebe4'
  surface-container-high: '#f4e5df'
  surface-container-highest: '#efdfd9'
  on-surface: '#211a16'
  on-surface-variant: '#3f4944'
  inverse-surface: '#372f2a'
  inverse-on-surface: '#fdeee7'
  outline: '#6f7a74'
  outline-variant: '#bec9c3'
  surface-tint: '#086b53'
  primary: '#005440'
  on-primary: '#ffffff'
  primary-container: '#0f6e56'
  on-primary-container: '#9aedcf'
  inverse-primary: '#84d6b9'
  secondary: '#7d5700'
  on-secondary: '#ffffff'
  secondary-container: '#feb71a'
  on-secondary-container: '#6b4b00'
  tertiary: '#7e3200'
  on-tertiary: '#ffffff'
  tertiary-container: '#a44300'
  on-tertiary-container: '#ffd4c0'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a0f3d4'
  primary-fixed-dim: '#84d6b9'
  on-primary-fixed: '#002117'
  on-primary-fixed-variant: '#00513e'
  secondary-fixed: '#ffdeaa'
  secondary-fixed-dim: '#ffba2c'
  on-secondary-fixed: '#271900'
  on-secondary-fixed-variant: '#5f4100'
  tertiary-fixed: '#ffdbcb'
  tertiary-fixed-dim: '#ffb692'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#7a3000'
  background: '#fff8f6'
  on-background: '#211a16'
  surface-variant: '#efdfd9'
typography:
  display-lg:
    fontFamily: Noto Serif
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Noto Serif
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Noto Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Noto Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Noto Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses the sanctity, pastoral purity, and artisanal integrity of authentic Tamil Nadu dairy craftsmanship. The design aesthetic balances ancient Dravidian cultural cues—such as rhythmic *kolam* line-art, burnished temple brass, and sacred agrarian motifs—with the friction-free, utilitarian precision of contemporary mobile-first digital commerce.

### Brand Personality & Emotional Impact
- **Sacred Wholesomeness (*Parisuddham*):** Transmits an immediate feeling of unadulterated freshness, evoking traditional morning milk distribution, brass measuring vessels (*azhakku*), and direct farmstead provenance.
- **Rooted Prestige:** Treats pastoral dairy as an heirloom treasure (*pokkisham*) rather than an industrial commodity, blending ceremonial reverence with modern safety standards.
- **Frictionless Accessibility:** Calibrated to serve multigenerational Tamil households across tier-1 cities and rural heartlands through prominent bilingual cues, WhatsApp-direct checkout, clear Cash-on-Delivery (COD) guarantees, and legible typographic scales.

### Visual Style Direction
The aesthetic fuses **Editorial Tactile Warmth** with **Clean Commerce Minimalism**. Clean, milky cream backgrounds (*FBF8F2*) provide breathing room, while deep forest teal (*0F6E56*) and temple gold (*FFB81C*) anchor interactive hierarchies. Kolam-inspired patterns appear selectively as delicate geometric borders, hairline separators, and empty-state accents, never impeding transaction paths.

## Colors

The palette draws directly from the natural landscape and cultural rituals of Tamil Nadu: fertile river basins, auspicious turmeric, morning sunlight, terracotta temple tiles, and rich farmstead earth.

### Core Roles
- **Primary (`#0F6E56` - Forest Teal):** Used for primary CTAs, main navigation surfaces, brand emblems, and verified farm provenance markers. Represents lush pastoral grazing and vitality.
- **Secondary (`#FFB81C` - Festive Turmeric Gold):** Used for gold-tier subscription passes, VIP badges, ratings, highlight borders, and secondary accent callouts.
- **Tertiary (`#FF6D00` - Sacred Saffron):** Applied to real-time milking/dispatch timers, urgent freshness tags, alert banners, and direct WhatsApp actions.
- **Neutral (`#2C2420` - Deep Umber):** The foundation for high-contrast typography, strict outlines, structural dividers, and icon strokes. Replaces harsh synthetic blacks with warm organic soil tones.

### Supporting Accents & Canvas
- **Kumkum Terracotta (`#C41E3A`):** Exclusively reserved for COD reassurance tags, batch authenticity wax-stamps, critical warnings, and festive celebration pills.
- **Earthy Warm Cream (`#FBF8F2`):** The universal canvas and primary surface container, reflecting natural A2 whole milk and raw unbleached cotton.
- **Pure Curd White (`#FFFFFF`):** Reserved for elevated cards, nested input panels, and high-readability content trays.

## Typography

The typographic hierarchy harmonizes Tamil epigraphy with modern digital e-commerce clarity across diverse vernacular reading proficiencies.

### Type System Hierarchy
- **Noto Serif (including Noto Serif Tamil):** Governs all editorial titles, product names, festive headings, and traditional certificates. Its chiselled, graceful proportions convey timeless trust and literary weight.
- **Noto Sans (including Noto Sans Tamil):** Powers descriptive copy, product provenance stories, recipe instructions, and customer reviews. Engineered for effortless legibility across Tamil script ligatures and Latin forms.
- **Inter:** Reserved strictly for transactional microcopy, bilingual UI badges, checkout forms, pricing figures (INR), and SKU timestamps where geometric clarity is required.

### Bilingual Typesetting Rules
When Latin and Tamil scripts appear side-by-side (such as `A2 Cow Ghee • பசு நெய்`), Latin baseline-aligns with the Tamil script's x-height. Tamil typography should maintain a 15–20% looser line height than pure Latin blocks to avoid conjunct collisions and preserve glyph anatomy.

## Layout & Spacing

The layout model is built on an adaptive fluid-grid framework designed for responsive density on compact mobile screens while preserving generous spatial rhythm on larger displays.

### Grid Architecture
- **Mobile (<640px):** 4-column fluid layout with `1rem` outer canvas margins and `1rem` gutters. Product listings use a 2-column card grid or full-width vertical detail stacks.
- **Tablet (640px - 1024px):** 8-column layout with `2rem` outer canvas margins and `1.5rem` gutters.
- **Desktop (>1024px):** 12-column layout max-capped at `1280px` centered width with `3rem` margins and `2rem` gutters.

### Spacing Principles
All spacing follows an 8pt architectural rhythm with a 4pt sub-grid for badges and compact metadata. Vertical rhythm ensures deliberate grouping: badges are pinned within `space-sm` of headings, product attributes are stacked with `space-md`, and disparate narrative sections breathe with `space-xl`.

## Elevation & Depth

This design system avoids sterile, cold drop-shadows in favor of grounded physical depth inspired by stacked terracotta tiers, brass platters, and warm morning light.

### Elevation Strategy
- **Layer 0 (Canvas Base):** Grounded in Earthy Warm Cream (`#FBF8F2`), unshadowed and tactile.
- **Layer 1 (Card & Product Tiles):** Pure Curd White (`#FFFFFF`) resting on the cream base, delineated by a subtle 1px border of Deep Umber at 8% opacity (`rgba(44, 36, 32, 0.08)`), cast over a warm, diffused ambient shadow: `0 2px 8px -2px rgba(44, 36, 32, 0.06), 0 1px 4px -1px rgba(44, 36, 32, 0.04)`.
- **Layer 2 (Dropdowns, WhatsApp Floaters, Bottom Sheets):** Crisp white surface with an amber-tinted shadow: `0 12px 24px -6px rgba(44, 36, 32, 0.12), 0 4px 12px -2px rgba(15, 110, 86, 0.08)`.
- **Layer 3 (Modals & Subscription Managers):** High-elevation focal planes bordered by a hairline Festive Turmeric Gold (`#FFB81C`) stroke, backdropped by a 40% Deep Umber scrim with 4px backdrop blur.

## Shapes

The design system adopts a **Soft (`1`)** shape language, utilizing conservative corner radii to preserve the structured, grounded dignity of traditional South Indian architectural joinery.

### Corner Radius Standards
- **Base Components (`0.25rem` / 4px):** Applied to badges, inputs, freshness chips, COD stamps, and verification indicators. Reflects crisp geometric clarity.
- **Structural Containers (`0.5rem` / 8px - `rounded-lg`):** Applied to product cards, modal surfaces, cart summaries, and hero promo pods.
- **Hero Modules & Drawers (`0.75rem` / 12px - `rounded-xl`):** Reserved for mobile navigation sheets, hero banner imagery, and bottom-drawer sheets.
- **Specialized Pill Shapes:** Fully rounded circular pill treatments (`9999px`) are exclusively used for status indicators, quantity counter caps, and the floating WhatsApp direct-order trigger.

## Components

### Buttons
- **Primary Action (Direct Buy / Add to Cart):** Solid Forest Teal (`#0F6E56`) with Pure Curd White typography. Padding: `0.75rem 1.5rem`. Soft corner radius (4px). Active states compress subtly with an inner shadow.
- **Secondary Action (View Farm Heritage / Subscriptions):** Outline button with 1.5px Forest Teal border, transparent background, and Deep Umber text. Hover brings in a 5% Forest Teal wash.
- **WhatsApp Direct Order Button:** Vibrant emerald surface (`#25D366`) with crisp white icon and bilingual text (`"Order via WhatsApp / வாட்ஸ்அப் வழி ஆர்டர்"`), elevated at Layer 2 with a pill-shaped form factor.

### Badges & Freshness Chips
- **Bilingual Freshness Indicator:** High-contrast pill featuring a pulsating Sacred Saffron (`#FF6D00`) or Forest Teal dot alongside uppercase microcopy: `MILKED TODAY • இன்று கறந்தது` or `CHURNED AT 4 AM`.
- **COD Priority Stamp:** Terracotta Kumkum (`#C41E3A`) hairline outline with 8% terracotta tint background, featuring a bold lock icon and label: `CASH ON DELIVERY AVAILABLE • நேரடி பணப்பட்டுவாடா`.
- **Authenticity Seal:** Circular or pill-shaped brass tag rendered in Festive Turmeric Gold (`#FFB81C`) with Deep Umber text denoting `100% PURE A2 DESI COW`.

### Product Cards
- Stacked white surface container with 4px corner rounding and a delicate 1px Umber border (`rgba(44, 36, 32, 0.08)`).
- Top corner: Pinned Freshness or Heritage Tag.
- Visual frame: Warm, naturally lit photography of farm glass bottles or clay butter pots against rustic timber or brass backdrops.
- Typography stack: Dual-script title (`A2 Pure Ghee / நாட்டு பசு நெய்`), volume specifier (`500 ml`), pricing displayed with heavy bold Inter numerals (`₹650`), paired with a quick-add step counter (`- 1 +`).

### Form Inputs & Selectors
- Background: Earthy Warm Cream (`#FBF8F2`) with a 1px Deep Umber stroke at 18% opacity.
- Focus state: Border transitions to Forest Teal (`#0F6E56`) with an accompanying 3px soft gold glow (`rgba(255, 184, 28, 0.25)`).
- Tamil placeholder support: Input labels consistently showcase dual-language aids (e.g., `Delivery Address / டெலிவரி முகவரி`).

### Checkboxes & Radio Controls
- Square with 2px radius (checkboxes) and concentric circular rings (radios).
- Active state fills with Forest Teal and displays a crisp white brass-style checkmark or solid center pip.